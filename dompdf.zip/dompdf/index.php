<?php

$html = '<img src="img.jpg">';
  // require_once 'dompdf/lib/html5lib/Parser.php';
  // require_once 'dompdf/lib/php-font-lib/src/FontLib/Autoloader.php';
  // require_once 'dompdf/lib/php-svg-lib/src/autoload.php';
  require_once 'dompdf/src/Autoloader.php';
  Dompdf\Autoloader::register();

use Dompdf\Dompdf;

$dompdf = new Dompdf();


$dompdf->set_option('isRemoteEnabled', true);
// $dompdf->loadHtml( file_get_contents('my.html') );
$dompdf->loadHtml($html);

$dompdf->setPaper('A4', 'portrait');

$dompdf->render();

//$dompdf->stream();
// View PDF on browser instead of download
$dompdf->stream("dompdf_outFRK.pdf", array("Attachment" => false));

?>